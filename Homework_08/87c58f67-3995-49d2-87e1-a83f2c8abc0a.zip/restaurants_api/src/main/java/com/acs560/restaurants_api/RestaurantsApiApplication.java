package com.acs560.restaurants_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantsApiApplication.class, args);
	}

}
